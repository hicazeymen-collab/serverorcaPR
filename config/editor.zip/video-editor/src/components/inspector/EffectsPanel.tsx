import React from 'react';
import { Layer } from '@/types/timeline';

interface EffectsPanelProps {
  layer: Layer;
  onChange: (property: string, value: any) => void;
}

export const EffectsPanel: React.FC<EffectsPanelProps> = ({ layer, onChange }) => {
  return (
    <div className="effects-panel">
      <div className="effects-list">
        {layer.effects.map(effect => (
          <div key={effect.id} className="effect-item">
            <div className="effect-header">
              <span className="effect-name">{effect.type}</span>
              <button className="effect-toggle">
                {effect.enabled ? '👁' : '👁‍🗨'}
              </button>
            </div>
            <div className="effect-controls">
              <label>Intensity</label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={effect.intensity}
                className="slider-input"
              />
            </div>
          </div>
        ))}
        
        {layer.effects.length === 0 && (
          <div className="no-effects">
            <p>No effects applied</p>
            <button className="add-effect-btn">Add Effect</button>
          </div>
        )}
      </div>
    </div>
  );
};