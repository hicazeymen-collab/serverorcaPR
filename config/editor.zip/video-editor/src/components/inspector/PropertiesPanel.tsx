import React from 'react';
import { Layer } from '@/types/timeline';

interface PropertiesPanelProps {
  layer: Layer;
  onChange: (property: string, value: any) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({ layer, onChange }) => {
  const handleInputChange = (property: string, value: string | number | boolean) => {
    onChange(property, value);
  };

  const NumberInput: React.FC<{
    label: string;
    value: number;
    property: string;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
  }> = ({ label, value, property, min, max, step = 1, unit }) => (
    <div className="property-row">
      <label className="property-label">{label}</label>
      <div className="number-input-group">
        <input
          type="number"
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={(e) => handleInputChange(property, parseFloat(e.target.value) || 0)}
          className="number-input"
        />
        {unit && <span className="input-unit">{unit}</span>}
      </div>
    </div>
  );

  const SliderInput: React.FC<{
    label: string;
    value: number;
    property: string;
    min: number;
    max: number;
    step?: number;
    unit?: string;
  }> = ({ label, value, property, min, max, step = 0.1, unit }) => (
    <div className="property-row">
      <label className="property-label">{label}</label>
      <div className="slider-input-group">
        <input
          type="range"
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={(e) => handleInputChange(property, parseFloat(e.target.value))}
          className="slider-input"
        />
        <span className="slider-value">
          {value.toFixed(step < 1 ? 1 : 0)}{unit}
        </span>
      </div>
    </div>
  );

  return (
    <div className="properties-panel">
      {/* Transform Properties */}
      <div className="property-section">
        <h3 className="section-title">Transform</h3>
        
        <div className="property-group">
          <h4 className="group-title">Position</h4>
          <div className="xy-input-group">
            <NumberInput
              label="X"
              value={layer.properties.position.x}
              property="properties.position.x"
              step={1}
              unit="px"
            />
            <NumberInput
              label="Y"
              value={layer.properties.position.y}
              property="properties.position.y"
              step={1}
              unit="px"
            />
          </div>
        </div>

        <div className="property-group">
          <h4 className="group-title">Scale</h4>
          <div className="xy-input-group">
            <NumberInput
              label="X"
              value={layer.properties.scale.x}
              property="properties.scale.x"
              min={0}
              step={0.1}
              unit="x"
            />
            <NumberInput
              label="Y"
              value={layer.properties.scale.y}
              property="properties.scale.y"
              min={0}
              step={0.1}
              unit="x"
            />
          </div>
          <div className="link-button-container">
            <button className="link-button" title="Link X and Y scale">
              🔗
            </button>
          </div>
        </div>

        <NumberInput
          label="Rotation"
          value={layer.properties.rotation}
          property="properties.rotation"
          min={-360}
          max={360}
          step={1}
          unit="°"
        />

        <div className="property-group">
          <h4 className="group-title">Anchor Point</h4>
          <div className="xy-input-group">
            <SliderInput
              label="X"
              value={layer.properties.anchor.x}
              property="properties.anchor.x"
              min={0}
              max={1}
              step={0.01}
              unit=""
            />
            <SliderInput
              label="Y"
              value={layer.properties.anchor.y}
              property="properties.anchor.y"
              min={0}
              max={1}
              step={0.01}
              unit=""
            />
          </div>
        </div>
      </div>

      {/* Appearance Properties */}
      <div className="property-section">
        <h3 className="section-title">Appearance</h3>
        
        <SliderInput
          label="Opacity"
          value={layer.opacity}
          property="opacity"
          min={0}
          max={1}
          step={0.01}
          unit="%"
        />

        <div className="property-row">
          <label className="property-label">Blend Mode</label>
          <select
            value={layer.blendMode}
            onChange={(e) => handleInputChange('blendMode', e.target.value)}
            className="select-input"
          >
            <option value="normal">Normal</option>
            <option value="multiply">Multiply</option>
            <option value="screen">Screen</option>
            <option value="overlay">Overlay</option>
            <option value="darken">Darken</option>
            <option value="lighten">Lighten</option>
            <option value="color-dodge">Color Dodge</option>
            <option value="color-burn">Color Burn</option>
            <option value="hard-light">Hard Light</option>
            <option value="soft-light">Soft Light</option>
            <option value="difference">Difference</option>
            <option value="exclusion">Exclusion</option>
          </select>
        </div>
      </div>

      {/* Layer Properties */}
      <div className="property-section">
        <h3 className="section-title">Layer</h3>
        
        <div className="property-row">
          <label className="property-label">Name</label>
          <input
            type="text"
            value={layer.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            className="text-input"
          />
        </div>

        <div className="property-row checkbox-row">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={layer.visible}
              onChange={(e) => handleInputChange('visible', e.target.checked)}
            />
            <span className="checkbox-text">Visible</span>
          </label>
        </div>

        <div className="property-row checkbox-row">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={layer.locked}
              onChange={(e) => handleInputChange('locked', e.target.checked)}
            />
            <span className="checkbox-text">Locked</span>
          </label>
        </div>
      </div>

      {/* Asset-specific properties */}
      {layer.type === 'video' && (
        <div className="property-section">
          <h3 className="section-title">Video</h3>
          
          <NumberInput
            label="Trim Start"
            value={layer.asset.trimStart}
            property="asset.trimStart"
            min={0}
            max={layer.asset.metadata.duration || 0}
            step={100}
            unit="ms"
          />

          <NumberInput
            label="Trim End"
            value={layer.asset.trimEnd}
            property="asset.trimEnd"
            min={layer.asset.trimStart}
            max={layer.asset.metadata.duration || 0}
            step={100}
            unit="ms"
          />
        </div>
      )}

      {layer.type === 'text' && (
        <div className="property-section">
          <h3 className="section-title">Text</h3>
          
          <div className="property-row">
            <label className="property-label">Content</label>
            <textarea
              value="Sample Text" // Would come from layer.textContent
              onChange={(e) => handleInputChange('textContent', e.target.value)}
              className="textarea-input"
              rows={3}
            />
          </div>

          <NumberInput
            label="Font Size"
            value={48} // Would come from layer.textProperties.fontSize
            property="textProperties.fontSize"
            min={8}
            max={200}
            step={1}
            unit="px"
          />

          <div className="property-row">
            <label className="property-label">Font Family</label>
            <select
              value="Arial" // Would come from layer.textProperties.fontFamily
              onChange={(e) => handleInputChange('textProperties.fontFamily', e.target.value)}
              className="select-input"
            >
              <option value="Arial">Arial</option>
              <option value="Helvetica">Helvetica</option>
              <option value="Times">Times</option>
              <option value="Courier">Courier</option>
            </select>
          </div>
        </div>
      )}
    </div>
  );
};