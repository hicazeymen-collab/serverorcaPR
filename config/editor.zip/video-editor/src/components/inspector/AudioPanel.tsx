import React from 'react';
import { Layer } from '@/types/timeline';

interface AudioPanelProps {
  layer: Layer;
  onChange: (property: string, value: any) => void;
}

export const AudioPanel: React.FC<AudioPanelProps> = ({ layer, onChange }) => {
  if (layer.type !== 'audio' && layer.type !== 'video') {
    return (
      <div className="audio-panel">
        <div className="no-audio">
          <p>This layer has no audio properties</p>
        </div>
      </div>
    );
  }

  return (
    <div className="audio-panel">
      <div className="audio-section">
        <h3 className="section-title">Audio</h3>
        
        <div className="audio-slider">
          <label>Volume</label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            defaultValue="1"
            className="slider-input"
          />
          <span>100%</span>
        </div>
        
        <div className="audio-slider">
          <label>Pan</label>
          <input
            type="range"
            min="-1"
            max="1"
            step="0.1"
            defaultValue="0"
            className="slider-input"
          />
          <span>Center</span>
        </div>
        
        <div className="audio-checkbox">
          <label>
            <input type="checkbox" defaultChecked />
            Enable Audio
          </label>
        </div>
        
        <div className="audio-checkbox">
          <label>
            <input type="checkbox" />
            Mute
          </label>
        </div>
      </div>
    </div>
  );
};