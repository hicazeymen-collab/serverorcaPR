import React from 'react';
import { Keyframe } from '@/types/timeline';

interface KeyframeMarkerProps {
  keyframe: Keyframe;
  position: number;
  isSelected: boolean;
  onSelect?: () => void;
  onDelete?: () => void;
}

export const KeyframeMarker: React.FC<KeyframeMarkerProps> = ({
  keyframe,
  position,
  isSelected,
  onSelect,
  onDelete
}) => {
  const getKeyframeColor = () => {
    switch (keyframe.property) {
      case 'position': return '#4A90E2';
      case 'scale': return '#50C878';
      case 'rotation': return '#F5A623';
      case 'opacity': return '#BD10E0';
      default: return '#888';
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect?.();
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete?.();
  };

  return (
    <div
      className={`keyframe-marker ${isSelected ? 'selected' : ''}`}
      style={{
        left: position - 4, // Center the 8px wide marker
        backgroundColor: getKeyframeColor(),
      }}
      onClick={handleClick}
      title={`${keyframe.property} keyframe at ${Math.round(keyframe.timestamp)}ms`}
    >
      {isSelected && (
        <button
          className="keyframe-delete"
          onClick={handleDelete}
        >
          ×
        </button>
      )}
    </div>
  );
};