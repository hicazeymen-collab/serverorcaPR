import React from 'react';

interface PlayheadProps {
  position: number; // pixel position
  height: number;   // total height to cover
}

export const Playhead: React.FC<PlayheadProps> = ({ position, height }) => {
  return (
    <div
      className="playhead"
      style={{
        left: position,
        height: height
      }}
    />
  );
};