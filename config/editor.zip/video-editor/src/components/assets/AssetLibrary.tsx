import React, { useState, useRef } from 'react';
import { useEditorStore } from '@/stores/editorStore';
import { Asset } from '@/types/timeline';
import './AssetLibrary.scss';

interface AssetItem extends Asset {
  thumbnail?: string;
}

export const AssetLibrary: React.FC = () => {
  const [activeTab, setActiveTab] = useState('media');
  const [searchQuery, setSearchQuery] = useState('');
  const [assets, setAssets] = useState<AssetItem[]>([]);
  const [draggedAsset, setDraggedAsset] = useState<AssetItem | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { actions: { addLayer } } = useEditorStore();

  const tabs = [
    { id: 'media', label: 'Media', icon: '🎬' },
    { id: 'effects', label: 'Effects', icon: '✨' },
    { id: 'transitions', label: 'Transitions', icon: '🔄' },
    { id: 'templates', label: 'Templates', icon: '📋' },
  ];

  const sampleAssets: AssetItem[] = [
    {
      id: 'sample-video-1',
      url: '/samples/video1.mp4',
      type: 'video',
      metadata: {
        duration: 30000,
        dimensions: { width: 1920, height: 1080 },
        format: 'mp4'
      },
      trimStart: 0,
      trimEnd: 30000,
      thumbnailUrl: '/samples/video1-thumb.jpg'
    },
    {
      id: 'sample-image-1',
      url: '/samples/image1.jpg',
      type: 'image',
      metadata: {
        dimensions: { width: 1920, height: 1080 },
        format: 'jpg'
      },
      trimStart: 0,
      trimEnd: 5000,
      thumbnailUrl: '/samples/image1-thumb.jpg'
    }
  ];

  const filteredAssets = assets.length > 0 ? assets : sampleAssets;

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const url = URL.createObjectURL(file);
      const asset: AssetItem = {
        id: `asset-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        url,
        type: file.type.startsWith('video/') ? 'video' : 'image',
        metadata: {
          dimensions: { width: 1920, height: 1080 }, // Default, would be detected
          format: file.name.split('.').pop() || 'unknown',
          fileSize: file.size
        },
        trimStart: 0,
        trimEnd: file.type.startsWith('video/') ? 10000 : 5000, // Default durations
        thumbnail: url
      };

      setAssets(prev => [...prev, asset]);
    });

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragStart = (asset: AssetItem) => {
    setDraggedAsset(asset);
  };

  const handleDragEnd = () => {
    setDraggedAsset(null);
  };

  const handleAssetDoubleClick = (asset: AssetItem) => {
    // Add to timeline at current playhead position
    const layer = {
      id: `layer-${Date.now()}`,
      type: asset.type,
      name: `${asset.type}-${assets.length + 1}`,
      startTime: 0, // Would use current playhead position
      endTime: asset.metadata.duration || 5000,
      duration: asset.metadata.duration || 5000,
      zIndex: 0,
      locked: false,
      visible: true,
      asset,
      properties: {
        position: { x: 0, y: 0 },
        scale: { x: 1, y: 1 },
        rotation: 0,
        opacity: 1,
        anchor: { x: 0.5, y: 0.5 },
        skew: { x: 0, y: 0 },
        blur: 0,
        brightness: 1,
        contrast: 1,
        saturation: 1,
        hue: 0
      },
      keyframes: [],
      effects: [],
      blendMode: 'normal' as const,
      opacity: 1
    };

    addLayer(layer);
  };

  const renderMediaTab = () => (
    <div className="media-tab">
      <div className="upload-area">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="video/*,image/*,audio/*"
          multiple
          style={{ display: 'none' }}
        />
        <button 
          className="upload-button"
          onClick={() => fileInputRef.current?.click()}
        >
          + Upload Media
        </button>
      </div>

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search assets..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="asset-grid">
        {filteredAssets
          .filter(asset => 
            asset.metadata.format?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            asset.type.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .map(asset => (
            <div
              key={asset.id}
              className="asset-item"
              draggable
              onDragStart={() => handleDragStart(asset)}
              onDragEnd={handleDragEnd}
              onDoubleClick={() => handleAssetDoubleClick(asset)}
              title={`${asset.type} - ${asset.metadata.format}`}
            >
              <div className="asset-thumbnail">
                {asset.thumbnailUrl ? (
                  <img src={asset.thumbnailUrl} alt="Asset thumbnail" />
                ) : (
                  <div className="placeholder-thumbnail">
                    {asset.type === 'video' ? '🎬' : asset.type === 'image' ? '🖼' : '🎵'}
                  </div>
                )}
                
                <div className="asset-type-badge">
                  {asset.type.toUpperCase()}
                </div>

                {asset.metadata.duration && (
                  <div className="asset-duration">
                    {Math.round(asset.metadata.duration / 1000)}s
                  </div>
                )}
              </div>

              <div className="asset-info">
                <div className="asset-name">
                  {asset.url.split('/').pop()?.split('.')[0] || 'Untitled'}
                </div>
                <div className="asset-details">
                  {asset.metadata.dimensions && 
                    `${asset.metadata.dimensions.width}x${asset.metadata.dimensions.height}`
                  }
                  {asset.metadata.fileSize && (
                    <span> • {formatFileSize(asset.metadata.fileSize)}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );

  const renderEffectsTab = () => (
    <div className="effects-tab">
      <div className="effect-categories">
        <h3>Color</h3>
        <div className="effect-item">Brightness/Contrast</div>
        <div className="effect-item">Color Balance</div>
        <div className="effect-item">Hue/Saturation</div>
        
        <h3>Blur & Stylize</h3>
        <div className="effect-item">Gaussian Blur</div>
        <div className="effect-item">Motion Blur</div>
        <div className="effect-item">Drop Shadow</div>
        
        <h3>Distort</h3>
        <div className="effect-item">Transform</div>
        <div className="effect-item">Warp</div>
      </div>
    </div>
  );

  const renderTransitionsTab = () => (
    <div className="transitions-tab">
      <div className="transition-grid">
        <div className="transition-item">Fade</div>
        <div className="transition-item">Dissolve</div>
        <div className="transition-item">Wipe</div>
        <div className="transition-item">Slide</div>
        <div className="transition-item">Push</div>
        <div className="transition-item">Zoom</div>
      </div>
    </div>
  );

  const renderTemplatesTab = () => (
    <div className="templates-tab">
      <div className="template-categories">
        <h3>Social Media</h3>
        <div className="template-item">Instagram Story</div>
        <div className="template-item">TikTok Vertical</div>
        <div className="template-item">YouTube Intro</div>
        
        <h3>Business</h3>
        <div className="template-item">Logo Reveal</div>
        <div className="template-item">Product Demo</div>
        <div className="template-item">Presentation</div>
      </div>
    </div>
  );

  return (
    <div className="asset-library">
      <div className="library-header">
        <h2>Assets</h2>
      </div>

      <div className="library-tabs">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="tab-icon">{tab.icon}</span>
            <span className="tab-label">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="library-content">
        {activeTab === 'media' && renderMediaTab()}
        {activeTab === 'effects' && renderEffectsTab()}
        {activeTab === 'transitions' && renderTransitionsTab()}
        {activeTab === 'templates' && renderTemplatesTab()}
      </div>
    </div>
  );
};

function formatFileSize(bytes: number): string {
  const sizes = ['B', 'KB', 'MB', 'GB'];
  if (bytes === 0) return '0B';
  
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const size = bytes / Math.pow(1024, i);
  
  return `${size.toFixed(1)}${sizes[i]}`;
}