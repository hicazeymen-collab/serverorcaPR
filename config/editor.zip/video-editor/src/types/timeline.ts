export interface Timeline {
  id: string;
  name: string;
  duration: number; // milliseconds
  fps: number;
  resolution: {
    width: number;
    height: number;
  };
  layers: Layer[];
  globalSettings: {
    backgroundColor: string;
    aspectRatio: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Layer {
  id: string;
  type: 'video' | 'image' | 'text' | 'audio' | 'shape' | 'effect';
  name: string;
  startTime: number; // ms
  endTime: number; // ms
  duration: number; // ms
  zIndex: number;
  locked: boolean;
  visible: boolean;
  asset: Asset;
  properties: PropertyMap;
  keyframes: Keyframe[];
  effects: Effect[];
  blendMode: BlendMode;
  opacity: number; // base opacity 0-1
}

export interface Asset {
  id: string;
  url: string;
  type: 'video' | 'image' | 'audio' | 'text';
  metadata: {
    duration?: number;
    dimensions?: { width: number; height: number };
    format?: string;
    fileSize?: number;
    framerate?: number;
  };
  trimStart: number;
  trimEnd: number;
  thumbnailUrl?: string;
}

export interface Keyframe {
  id: string;
  layerId: string;
  timestamp: number; // ms
  property: keyof PropertyMap | 'custom';
  value: any;
  easing: EasingType;
  bezierParams?: [number, number, number, number];
}

export interface PropertyMap {
  position: { x: number; y: number };
  scale: { x: number; y: number };
  rotation: number; // degrees
  opacity: number; // 0-1
  anchor: { x: number; y: number }; // pivot point percentage
  skew: { x: number; y: number };
  blur: number;
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
}

export interface Effect {
  id: string;
  type: 'blur' | 'glow' | 'shadow' | 'colorCorrection' | 'distortion' | 'custom';
  enabled: boolean;
  params: Record<string, any>;
  intensity: number;
}

export type BlendMode = 
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion';

export type EasingType =
  | 'linear'
  | 'ease-in'
  | 'ease-out'
  | 'ease-in-out'
  | 'cubic-bezier'
  | 'step-start'
  | 'step-end'
  | 'elastic'
  | 'bounce';

export interface RenderJob {
  id: string;
  timelineId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  outputUrl?: string;
  error?: string;
  startedAt?: Date;
  completedAt?: Date;
}

export interface SnapPoint {
  position: number;
  type: 'playhead' | 'edge' | 'keyframe' | 'marker';
  ownerId: string;
  strength: number;
}

export interface Selection {
  layers: string[];
  keyframes: string[];
  timeRange?: { start: number; end: number };
}