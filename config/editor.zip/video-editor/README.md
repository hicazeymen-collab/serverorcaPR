// src/app/reels-montage/page.tsx
"use client";
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { useToast } from "@/hooks/use-toast";
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db, appId as currentAppId } from '@/lib/firebase';
import { collection, onSnapshot, query, doc, updateDoc, getDoc, setDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import type { Podcast, Episode, ShortFormContentRow, User, ReelRenderOptions, Layer as LayerType, VideoPositionKeyframe, Keyframe, ReelForRender, GuestProfile, PositionKeyframe, RotationKeyframe, ScaleKeyframe, OpacityKeyframe, ReelTemplate, TranscriptSegment } from '@/types';
import { paths as appPathsDefinition } from '@/lib/constants';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  UploadCloud, PlayCircle, Download, Bot, Tv, Loader2, Settings, Image as ImageIcon, Type as TypeIcon, MapPin,
  FileVideo, ListVideo, AlertTriangle, ShieldAlert, Home, Film, Sparkles, Wand2, Link as LinkIcon, Move, ZoomIn, Text, Timer, Eye, EyeOff, Layers as LayersIcon, PlusCircle, X as XIcon, Check, Repeat, Search, ExternalLink, Volume2, VolumeX, Pause, Share2, Send, RefreshCcw, ChevronLeft, ChevronRight, Trash2, SkipBack, SkipForward
} from 'lucide-react';
import Image from 'next/image';
import { usePermissions } from '@/lib/permissions';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { v4 as uuidv4 } from 'uuid';
import { cn } from '@/lib/utils';
import { Textarea } from '@/components/ui/textarea';
import { Timeline } from '@/components/reels/Timeline';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from "@/components/ui/dialog";
import * as timecodeUtils from '@/lib/timecode';
import { cleanForFirestore } from '@/lib/utils';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { LayerInspector } from '@/components/reels/LayerInspector';
import HTMLVideoPlayer, { type HTMLPlayerControls } from '@/components/episodes/workflow-steps/shared/HTMLVideoPlayer';
import VisualReelEditor, { type VisualReelEditorHandles, getLayerText } from '@/components/reels/VisualReelEditor';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";


const currentAppPaths = appPathsDefinition(currentAppId);
const logoUrl = "https://firebasestorage.googleapis.com/v0/b/bathhadeth/o/logo%2Flogo.png?alt=media";

const getGoogleDriveEmbedUrl = (url?: string): string | null => {
    if (!url || typeof url !== 'string' || (!url.startsWith('http://') && !url.startsWith('https://'))) {
        return null;
    }
    try {
        const driveUrl = new URL(url);
        let fileId: string | null = null;
        if (driveUrl.hostname === 'drive.google.com') {
            const pathParts = driveUrl.pathname.split('/');
            const dIndex = pathParts.indexOf('d');
            if (dIndex !== -1 && pathParts.length > dIndex + 1) {
                fileId = pathParts[dIndex + 1];
            } else if (driveUrl.searchParams.get('id')) {
                fileId = driveUrl.searchParams.get('id');
            }
        }
        return fileId ? `https://drive.google.com/file/d/${fileId}/preview` : null;
    } catch (e) {
        console.warn("[ReelsMontage] Error parsing Google Drive URL for embed:", url, e);
        return null;
    }
};

const ReelListItem: React.FC<{
  reel: ReelForRender;
  isSelected: boolean;
  onSelect: () => void;
  onCheckboxChange: () => void;
  episodeCode?: string;
}> = ({ reel, isSelected, onSelect, onCheckboxChange, episodeCode }) => {
  const shortCode = episodeCode ? `${episodeCode.split('_')[0]}_SHORT_${String(reel.number).padStart(2, '0')}` : `#${reel.number}`;
  const displayTitle = reel.line1 || `عنوان غير متوفر`;

  return (
    <div
      onClick={onSelect}
      className={cn(
        "flex items-center gap-3 p-2 rounded-md cursor-pointer border",
        isSelected ? 'bg-primary/10 border-primary' : 'border-transparent hover:bg-muted'
      )}
    >
      <Checkbox
        checked={reel.isSelected}
        onCheckedChange={onCheckboxChange}
        onClick={(e) => e.stopPropagation()}
        className="shrink-0"
      />
      <div className="flex-grow min-w-0">
        <p className="font-semibold text-sm truncate" title={displayTitle}>
          {displayTitle}
        </p>
        <p className="text-xs text-muted-foreground font-mono" title={`المدة: ${reel.duration}`}>
          <span className="text-primary/80 font-bold">{shortCode}</span> | المدة: {reel.duration}
        </p>
      </div>
      <div className="flex flex-col items-center gap-1 shrink-0">
          <TooltipProvider>
            {reel.renderStatus === 'completed' && reel.finalUrl ? (
                <Tooltip>
                    <TooltipTrigger>
                        <Check className="w-4 h-4 text-green-500"/>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>الرندر مكتمل</p>
                    </TooltipContent>
                </Tooltip>
            ) : reel.renderStatus === 'rendering' ? (
                <Tooltip>
                    <TooltipTrigger>
                        <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>جاري الرندر ({reel.progress || 0}%)</p>
                    </TooltipContent>
                </Tooltip>
            ) : reel.renderStatus === 'failed' ? (
                <Tooltip>
                    <TooltipTrigger>
                        <AlertTriangle className="w-4 h-4 text-destructive"/>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>فشل الرندر</p>
                    </TooltipContent>
                </Tooltip>
            ) : null}
        </TooltipProvider>
      </div>
    </div>
  );
};

const VideoPlayer: React.FC<{
    selectedReel: ReelForRender | null;
    isPlaying: boolean;
    isMuted: boolean;
    onPlayPause: () => void;
    onReplay: () => void;
    onSeek: (value: number[]) => void;
    onToggleMute: () => void;
    relativeCurrentTime: number;
    clipDuration: number;
    onAddKeyframe: (property: keyof LayerType | 'video.position', time: number) => void;
    onTimecodeNudge: (field: 'tcIn' | 'tcOut', amount: number) => void;
    onGoToStart: () => void;
    onGoToEnd: () => void;
}> = ({ selectedReel, isPlaying, isMuted, onPlayPause, onReplay, onSeek, onToggleMute, relativeCurrentTime, clipDuration, onAddKeyframe, onTimecodeNudge, onGoToStart, onGoToEnd }) => {
    return (
        <div className="p-2 bg-card rounded-md border flex-shrink-0" dir="ltr">
             <div className="flex items-center justify-between gap-2">
                 <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onTimecodeNudge('tcIn', -0.1)}><ChevronLeft className="w-4 h-4"/></Button>
                    <div className="text-center">
                        <Label htmlFor="tcin-display" className="text-[10px] text-muted-foreground -mb-1 block">TC IN</Label>
                        <div id="tcin-display" className="h-8 flex items-center justify-center font-mono text-sm px-3 text-primary">{selectedReel?.renderOptions?.tcIn || '00:00:00.000'}</div>
                    </div>
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onTimecodeNudge('tcIn', 0.1)}><ChevronRight className="w-4 h-4"/></Button>
                </div>
                
                <div className="flex flex-col items-center flex-grow mx-4">
                    <div className="text-foreground text-xs font-mono drop-shadow-md w-24 text-center">
                        {timecodeUtils.formatSecondsToHHMMSSms(relativeCurrentTime).substring(3, 8)} / {timecodeUtils.formatSecondsToHHMMSSms(clipDuration).substring(3, 8)}
                    </div>
                    <div className="relative flex-grow w-full mt-1">
                        <Slider
                            value={[relativeCurrentTime]}
                            min={0}
                            max={clipDuration > 0 ? clipDuration : 1}
                            step={0.1}
                            onValueChange={onSeek}
                            className="w-full"
                        />
                    </div>
                </div>

                <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onTimecodeNudge('tcOut', -0.1)}><ChevronLeft className="w-4 h-4"/></Button>
                    <div className="text-center">
                        <Label htmlFor="tcout-display" className="text-[10px] text-muted-foreground -mb-1 block">TC OUT</Label>
                        <div id="tcout-display" className="h-8 flex items-center justify-center font-mono text-sm px-3 text-primary">{selectedReel?.renderOptions?.tcOut || '00:00:00.000'}</div>
                    </div>
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onTimecodeNudge('tcOut', 0.1)}><ChevronRight className="w-4 h-4"/></Button>
                </div>
            </div>
             <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t">
                <Button size="icon" className="rounded-full bg-black/50 text-white" onClick={onGoToStart} title="Go to Start">
                    <SkipBack className="w-4 h-4"/>
                </Button>
                <Button size="icon" className="rounded-full bg-black/50 text-white" onClick={onReplay}>
                    <Repeat className="w-4 h-4"/>
                </Button>
                <Button size="icon" className="rounded-full bg-black/50 text-white w-12 h-12" onClick={onPlayPause}>
                    {isPlaying ? <Pause className="w-6 h-6"/> : <PlayCircle className="w-6 h-6"/>}
                </Button>
                 <Button size="icon" className="rounded-full bg-black/50 text-white" onClick={onToggleMute}>
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button size="icon" className="rounded-full bg-black/50 text-white" onClick={() => onAddKeyframe('video.position', relativeCurrentTime)} title="إضافة نقطة تحكم">
                          <MapPin className="w-4 h-4"/>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent><p>إضافة نقطة تحكم لجميع الخصائص في الوقت الحالي</p></TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <Button size="icon" className="rounded-full bg-black/50 text-white" onClick={onGoToEnd} title="Go to End">
                    <SkipForward className="w-4 h-4"/>
                </Button>
            </div>
        </div>
    );
};

const CompletedReelCard: React.FC<{ reel: ReelForRender; setVideoInModal: (url: string) => void; toast: any }> = ({ reel, setVideoInModal, toast }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);

    const togglePlay = (e: React.MouseEvent) => {
        e.stopPropagation();
        const video = videoRef.current;
        if (video) {
            if (video.paused) {
                video.play();
                setIsPlaying(true);
            } else {
                video.pause();
                setIsPlaying(false);
            }
        }
    };

    return (
        <Card className="w-40 shrink-0 aspect-[9/16] flex flex-col justify-between overflow-hidden bg-muted group/reel-card">
            <CardHeader className="p-2 relative z-20">
                <CardTitle className="text-xs truncate font-semibold text-white drop-shadow-md">المقطع #{reel.number}</CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-grow flex flex-col items-center justify-center relative">
                {reel.renderStatus === 'rendering' ? (
                    <div className="space-y-2 w-full text-center p-4">
                        <Image src={logoUrl} alt="Logo" width={60} height={60} className="mx-auto animate-logo-pulse opacity-80 invert" data-ai-hint="logo"/>
                        <Progress value={reel.progress} className="h-1.5" />
                        <p className="text-xs text-muted-foreground">{reel.progress || 0}% - جاري...</p>
                    </div>
                ) : reel.renderStatus === 'completed' && reel.finalUrl ? (
                    <div className="absolute inset-0 w-full h-full" onClick={togglePlay}>
                        <video
                            ref={videoRef}
                            src={reel.finalUrl}
                            poster={reel.thumbnailLink || undefined}
                            playsInline
                            loop
                            className="absolute inset-0 w-full h-full object-cover rounded-md bg-black"
                            onPlay={() => setIsPlaying(true)}
                            onPause={() => setIsPlaying(false)}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent z-10 pointer-events-none" />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 transition-opacity duration-300 opacity-0 group-hover/reel-card:opacity-100 z-20 pointer-events-none">
                            {isPlaying ? (
                                <Pause className="w-10 h-10 text-white/70 drop-shadow-lg" />
                            ) : (
                                <PlayCircle className="w-10 h-10 text-white/70 drop-shadow-lg" />
                            )}
                        </div>
                    </div>
                ) : (
                     <div className="flex flex-col items-center justify-center text-center text-destructive p-4">
                        <AlertTriangle className="w-8 h-8 mb-1"/>
                        <p className="text-xs font-semibold">فشل الرندر</p>
                    </div>
                )}
            </CardContent>
            {reel.renderStatus === 'completed' && reel.finalUrl && (
                <div className="p-1.5 border-t bg-black/20 relative z-20 flex items-center justify-around">
                    <a href={reel.finalUrl} download onClick={e => e.stopPropagation()}><Button variant="ghost" size="icon" className="h-7 w-7 text-white/80 hover:text-white bg-black/20 hover:bg-black/40"><Download className="w-4 h-4"/></Button></a>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-white/80 hover:text-white bg-black/20 hover:bg-black/40" onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(reel.finalUrl!); toast({title: 'تم نسخ الرابط'}); }}><Share2 className="w-4 h-4"/></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-white/80 hover:text-white bg-black/20 hover:bg-black/40" onClick={(e) => { e.stopPropagation(); setVideoInModal(reel.finalUrl!);}}><ExternalLink className="w-4 h-4"/></Button>
                </div>
            )}
        </Card>
    );
};


export default function ReelsMontagePage() {
    const router = useRouter();
    const { toast } = useToast();
    const { hasPermission, isLoading: isPermissionsLoading } = usePermissions();
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [isAuthLoading, setIsAuthLoading] = useState(true);
    const [canAccess, setCanAccess] = useState<boolean | null>(null);
    
    const [allPodcasts, setAllPodcasts] = useState<Podcast[]>([]);
    const [allGuestProfiles, setAllGuestProfiles] = useState<GuestProfile[]>([]);
    const [allEpisodes, setAllEpisodes] = useState<Episode[]>([]);
    const [isLoadingData, setIsLoadingData] = useState(true);

    const [selectedPodcastId, setSelectedPodcastId] = useState<string>('');
    const [selectedEpisodeId, setSelectedEpisodeId] = useState<string | null>(null);
    
    const [highQualityVideoLink, setHighQualityVideoLink] = useState<string>('');
    const [highQualityVideoPath, setHighQualityVideoPath] = useState<string>('');
    const [isCheckingForVideo, setIsCheckingForVideo] = useState(false);
    const [missingFiles, setMissingFiles] = useState<string[]>([]);
    
    const [localReels, setLocalReels] = useState<ReelForRender[]>([]);
    const [selectedReelId, setSelectedReelId] = useState<string | null>(null);
    const [selectedLayerId, setSelectedLayerId] = useState<string | null>(null);
    
    const [isRendering, setIsRendering] = useState(false);
    
    const [isUploadingAsset, setIsUploadingAsset] = useState<boolean>(false);
    const [isUploadingFont, setIsUploadingFont] = useState<boolean>(false);
    
    const [isSavingVmIp, setIsSavingVmIp] = useState(false);
    const [vmIpAddress, setVmIpAddress] = useState('');
    
    const [isPlaying, setIsPlaying] = useState(false);
    const [isMuted, setIsMuted] = useState(true);
    const [relativeCurrentTime, setRelativeCurrentTime] = useState(0); 
    const [videoInModal, setVideoInModal] = useState<string | null>(null);
    
    const playerRef = useRef<VisualReelEditorHandles>(null);
    const [jsonToRender, setJsonToRender] = useState('');
    const [jsonFile, setJsonFile] = useState<File | null>(null);
    const [webhookUrl, setWebhookUrl] = useState('');
    const [isSendingWebhook, setIsSendingWebhook] = useState(false);
    const [showWebhookDialog, setShowWebhookDialog] = useState(false);
    const [isTestingWebhook, setIsTestingWebhook] = useState(false);

    const selectedPodcast = useMemo(() => allPodcasts.find(p => p.id === selectedPodcastId), [selectedPodcastId, allPodcasts]);
    const montageAssets = useMemo(() => selectedPodcast?.montageAssets || {}, [selectedPodcast]);
    const montageFonts = useMemo(() => selectedPodcast?.montageFonts || [], [selectedPodcast]);
    
    const selectedEpisode = useMemo(() => {
        if (!selectedEpisodeId) return null;
        return allEpisodes.find(ep => ep.id === selectedEpisodeId) || null;
    }, [selectedEpisodeId, allEpisodes]);
    
    const selectedReel = useMemo(() => {
        if (!selectedReelId) return null;
        return localReels.find(r => r.id === selectedReelId) || null;
    }, [selectedReelId, localReels]);
    
    const selectedLayer = useMemo(() => {
        if (!selectedLayerId || !selectedReel) return null;
        return selectedReel.renderOptions?.layers?.find(l => l.id === selectedLayerId) || null;
    }, [selectedLayerId, selectedReel]);

    const sourceVideoUrl = useMemo(() => highQualityVideoLink, [highQualityVideoLink]);
    
    const clipDuration = useMemo(() => {
        if (!selectedReel?.renderOptions) return 0;
        const tcInSec = timecodeUtils.parseTimecodeToSeconds(selectedReel.renderOptions?.tcIn);
        const tcOutSec = timecodeUtils.parseTimecodeToSeconds(selectedReel.renderOptions?.tcOut);
        return Math.max(0, tcOutSec - tcInSec);
    }, [selectedReel]);

    const onPodcastUpdate = useCallback(async (podcastId: string, updates: Partial<Podcast>) => {
        if (!podcastId) return;
        const podcastRef = doc(db, currentAppPaths.podcasts, podcastId);
        try {
            await updateDoc(podcastRef, updates);
            toast({ title: "تم تحديث البودكاست", description: "تم حفظ الإعدادات الجديدة بنجاح."});
        } catch (error: any) {
            toast({ title: "خطأ", description: `فشل تحديث البودكاست: ${error.message}`, variant: "destructive"});
        }
    }, [toast]);
    
    const onReelOptionsChange = useCallback((reelId: string, updatedOptions: Partial<ReelRenderOptions>) => {
        setLocalReels(prevReels =>
            prevReels.map(reel => {
                if (reel.id === reelId) {
                    const newRenderOptions = {
                        ...(reel.renderOptions || {}),
                        ...updatedOptions,
                    };
                    if (updatedOptions.video) {
                        newRenderOptions.video = {
                            ...(reel.renderOptions?.video || {}),
                            ...updatedOptions.video,
                        };
                    }
                    return { ...reel, renderOptions: newRenderOptions };
                }
                return reel;
            })
        );
    }, []);

    const onLayersChange = useCallback((updater: (prevLayers: LayerType[]) => LayerType[]) => {
        if (!selectedReelId) return;
        setLocalReels(prevReels =>
            prevReels.map(reel => {
                if (reel.id === selectedReelId) {
                    const updatedReel = { ...reel };
                    const currentLayers = reel.renderOptions?.layers || [];
                    const newLayers = typeof updater === 'function' ? updater(currentLayers) : updater;
                    updatedReel.renderOptions = {
                        ...(reel.renderOptions || {}),
                        layers: newLayers,
                    };
                    return updatedReel;
                }
                return reel;
            })
        );
    }, [selectedReelId]);
    
    const onAssetUpload = useCallback(async (file: File | null) => {
        if (!file || !selectedPodcast) return;
        setIsUploadingAsset(true);
        const formData = new FormData();
        formData.append('file', file);
        formData.append('uploadContext', 'montageAsset');
        formData.append('podcastCode', selectedPodcast.code);
        try {
            const response = await fetch('/api/upload', { method: 'POST', body: formData });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'فشل الرفع');
            
            const assetKey = file.name.split('.')[0].replace(/[^a-zA-Z0-9]/g, '_');
            const newAsset = { url: result.url, path: result.path };
            
            const newAssets = { ...(selectedPodcast.montageAssets || {}), [assetKey]: newAsset };
            await onPodcastUpdate(selectedPodcast.id, { montageAssets: newAssets });
            
            toast({ title: "تم رفع الأصل بنجاح", description: `تم حفظ "${assetKey}" للاستخدام.` });
        } catch (error: any) {
            toast({ title: "خطأ", description: error.message, variant: "destructive" });
        } finally {
            setIsUploadingAsset(false);
        }
    }, [selectedPodcast, onPodcastUpdate, toast]);
    
    const onFontUpload = useCallback(async (file: File | null) => {
        if (!file || !selectedPodcast) return;
        setIsUploadingFont(true);
        const formData = new FormData();
        formData.append('file', file);
        formData.append('uploadContext', 'montageFont');
        formData.append('podcastCode', selectedPodcast.code);
        try {
            const response = await fetch('/api/upload', { method: 'POST', body: formData });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'فشل الرفع');

            const fontName = file.name.split('.')[0];
            const newFont = { name: fontName, url: result.url, path: result.path };
            
            await onPodcastUpdate(selectedPodcast.id, { montageFonts: [...(selectedPodcast.montageFonts || []), newFont] });

            toast({ title: "تم رفع الخط بنجاح", description: `تم حفظ "${fontName}" للاستخدام.` });
        } catch (error: any) {
            toast({ title: "خطأ", description: error.message, variant: "destructive" });
        } finally {
            setIsUploadingFont(false);
        }
    }, [selectedPodcast, onPodcastUpdate, toast]);

    const handlePlayerStateChange = useCallback((state: 'playing' | 'paused' | 'ended' | 'idle' | 'error') => {
        if (state === 'playing') setIsPlaying(true);
        else if (state === 'paused' || state === 'ended') setIsPlaying(false);
    }, []);

    const handlePlayPause = useCallback(() => {
        if(playerRef.current) {
            isPlaying ? playerRef.current.pause() : playerRef.current.play();
        }
    }, [isPlaying]);

    const handleReplay = useCallback(() => {
        if (playerRef.current) {
            playerRef.current.seekTo(0);
            playerRef.current.play();
        }
    }, []);
    
    const handleSeek = useCallback((value: number[]) => {
        if (playerRef.current) {
            playerRef.current.seekTo(value[0]);
        }
    }, []);

    const toggleMute = useCallback(() => {
        setIsMuted(prev => !prev);
    }, []);
    
    const handleBatchRender = useCallback(async () => {
        const reelsToRender = localReels.filter(r => r.isSelected);
        if (reelsToRender.length === 0) {
            toast({ title: 'لم يتم تحديد مقاطع', description: 'الرجاء تحديد مقطع واحد على الأقل للرندر.', variant: 'destructive' });
            return;
        }
        if (!highQualityVideoPath) {
            toast({ title: 'لا يوجد فيديو مصدر', description: 'الرجاء التحقق من وجود فيديو المصدر أو رفعه يدويًا.', variant: 'destructive' });
            return;
        }
        if (!selectedPodcast || !selectedEpisode) {
            toast({ title: 'معلومات ناقصة', description: 'الرجاء اختيار بودكاست وحلقة.', variant: 'destructive' });
            return;
        }

        setIsRendering(true);
        toast({ title: `بدء عملية الرندر لـ ${reelsToRender.length} مقطع...`, description: 'سيتم إعلامك عند اكتمال كل مقطع.' });
        
        const apiPayload = {
            sourceVideoPath: highQualityVideoPath,
            podcastCode: selectedPodcast.code,
            episodeCode: selectedEpisode.episodeCode,
            episodeId: selectedEpisode.id,
            reels: reelsToRender.map(reel => {
                const renderOptionsWithDynamicText = {
                    ...reel.renderOptions,
                    layers: (reel.renderOptions?.layers || []).map(layer => {
                        return {
                            ...layer,
                            text: getLayerText(layer, reel, selectedEpisode, allGuestProfiles),
                            imagePath: layer.imagePath?.toLowerCase().endsWith('.webm') 
                                ? layer.imagePath.replace(/\.webm$/i, '.mov')
                                : layer.imagePath,
                        };
                    })
                };
                return {
                    id: reel.id,
                    number: reel.number,
                    options: renderOptionsWithDynamicText,
                };
            })
        };
        
        try {
            const response = await fetch('/api/render-reels', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cleanForFirestore(apiPayload)),
            });
            const result = await response.json();
            if (!response.ok) { throw new Error(result.error || 'فشل إرسال طلب الرندر.'); }
            toast({ title: "تم إرسال الطلب بنجاح", description: result.message, className: "bg-green-500 text-white" });
            
            setLocalReels(prev => prev.map(reel => reelsToRender.some(r => r.id === reel.id) ? { ...reel, renderStatus: 'rendering', progress: 0 } : reel));

        } catch (error: any) {
            toast({ title: "خطأ في إرسال طلب الرندر", description: error.message, variant: "destructive" });
        } finally {
            setIsRendering(false);
        }
    }, [localReels, highQualityVideoPath, selectedPodcast, selectedEpisode, allGuestProfiles, toast]);


    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
            if (fbUser) {
                const userDocRef = doc(db, currentAppPaths.users, fbUser.uid);
                try {
                    const docSnap = await getDoc(userDocRef);
                    setCurrentUser(docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } as User : null);
                } catch (error) {
                    console.error("Error fetching user data:", error);
                    setCurrentUser(null);
                }
            } else {
                setCurrentUser(null);
            }
            setIsAuthLoading(false);
        });

        const unsubPodcasts = onSnapshot(query(collection(db, currentAppPaths.podcasts)), snapshot => {
            setAllPodcasts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Podcast)));
        });

        const unsubGuests = onSnapshot(query(collection(db, currentAppPaths.guests)), snapshot => {
            setAllGuestProfiles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GuestProfile)));
        });

        const configDocRef = doc(db, currentAppPaths.appConfigurationDoc('render_server_config'));
        const unsubConfig = onSnapshot(configDocRef, (snap) => {
            if (snap.exists()) {
                setVmIpAddress(snap.data().vmIpAddress || '');
            }
        });
        
        const unsubEpisodes = onSnapshot(query(collection(db, currentAppPaths.episodes)), snapshot => {
            const episodesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Episode));
            setAllEpisodes(episodesData);
            if (isLoadingData) setIsLoadingData(false);
        }, (error) => {
            console.error("Error fetching all episodes:", error);
            if (isLoadingData) setIsLoadingData(false);
        });


        return () => {
            unsubscribe();
            unsubPodcasts();
            unsubGuests();
            unsubConfig();
            unsubEpisodes();
        };
    }, [isLoadingData]);

    useEffect(() => {
        if (!isAuthLoading && !isPermissionsLoading) {
            if (currentUser) {
                setCanAccess(hasPermission(currentUser, 'canAccessReelsMontagePage'));
            } else {
                setCanAccess(false);
            }
        }
    }, [currentUser, isAuthLoading, isPermissionsLoading, hasPermission]);


    const availableEpisodes = useMemo(() => {
        if (!selectedPodcastId) return [];
        const episodesWithShorts = new Set(allEpisodes
            .filter(ep => ep.shortFormContent && ep.shortFormContent.length > 0)
            .map(ep => ep.id)
        );
        return allEpisodes
            .filter(ep => ep.podcastId === selectedPodcastId && episodesWithShorts.has(ep.id))
            .sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    }, [selectedPodcastId, allEpisodes]);
    
    
    useEffect(() => {
        if (!selectedEpisodeId) {
            setLocalReels([]);
            setSelectedReelId(null);
            setMissingFiles([]);
            return;
        }

        const unsub = onSnapshot(doc(db, currentAppPaths.episodes, selectedEpisodeId), (doc) => {
            if (doc.exists()) {
                const episodeToLoad = { id: doc.id, ...doc.data() } as Episode;
                const podcastForEpisode = allPodcasts.find(p => p.id === episodeToLoad.podcastId);
                const defaultTemplate = podcastForEpisode?.templates?.find(t => t.id === podcastForEpisode.defaultTemplateId);
                const defaultRenderOptions = defaultTemplate?.options || {};

                const reelsFromEpisode = (episodeToLoad.shortFormContent || []).map(row => {
                    const existingLayers = row.renderOptions?.layers || [];
                    
                    const layersWithDefaults = [...existingLayers];

                    return {
                        ...row,
                        episodeId: episodeToLoad.id,
                        isSelected: false,
                        line1: row.line1,
                        line2: row.line2,
                        renderOptions: {
                            ...defaultRenderOptions,
                            ...(row.renderOptions || {}),
                            layers: layersWithDefaults,
                            tcIn: row.tcIn,
                            tcOut: row.tcOut,
                        }
                    };
                });
                setLocalReels(reelsFromEpisode);
                
                if (reelsFromEpisode.length > 0 && (!selectedReelId || !reelsFromEpisode.find(r => r.id === selectedReelId))) {
                    setSelectedReelId(reelsFromEpisode[0].id);
                } else if (reelsFromEpisode.length === 0) {
                    setSelectedReelId(null);
                }
            } else {
                setLocalReels([]);
                setSelectedReelId(null);
            }
        });

        return () => unsub();
    }, [selectedEpisodeId, allPodcasts, selectedReelId]);
    
    const checkForExistingVideo = useCallback(async (podcastCode: string, episodeCode: string) => {
        if (!episodeCode || !podcastCode) {
            return;
        }

        setIsCheckingForVideo(true);
        setHighQualityVideoLink('');
        setHighQualityVideoPath('');
        setMissingFiles([]);

        try {
            const response = await fetch(`/api/check-gcs-file?podcastCode=${podcastCode}&episodeCode=${episodeCode}`);
            const data = await response.json();

            if (data.success && data.foundFiles) {
                setMissingFiles(data.missingFiles || []);
                const pgmFile = data.foundFiles.pgm;
                if (pgmFile) {
                    setHighQualityVideoLink(pgmFile.url);
                    setHighQualityVideoPath(pgmFile.path);
                    toast({
                        title: 'تم العثور على فيديو المصدر',
                        description: `تم تعيين الملف "${pgmFile.name}" كفيديو أساسي.`,
                        className: 'bg-green-500 text-white'
                    });
                } else {
                    toast({ title: 'ملف PGM المصدر غير موجود', description: 'لا يمكن العثور على الفيديو الأساسي للبرنامج. الرجاء التحقق من الملفات المرفوعة.', variant: 'destructive', duration: 7000 });
                }

                setLocalReels(prevReels => {
                    return prevReels.map(reel => {
                        const clipDurationForLayer = timecodeUtils.parseTimecodeToSeconds(reel.tcOut) - timecodeUtils.parseTimecodeToSeconds(reel.tcIn);
                        const newLayers = [...(reel.renderOptions?.layers || [])];
                        const existingLayerPaths = new Set(newLayers.map(l => l.imagePath));
                        const { guestCam, presenterCam, mixdown1, mixdown2 } = data.foundFiles;

                        const addLayerIfNotExists = (layerData: Omit<LayerType, 'id'>, duration: number) => {
                            if (layerData.imagePath && !existingLayerPaths.has(layerData.imagePath)) {
                                newLayers.push({ id: uuidv4(), ...layerData, duration });
                            }
                        };
                        
                        addLayerIfNotExists({ type: 'video', visible: false, imagePath: guestCam?.path, assetKey: 'guestCam', zIndex: 2, startTime: 0 }, clipDurationForLayer);
                        addLayerIfNotExists({ type: 'video', visible: false, imagePath: presenterCam?.path, assetKey: 'presenterCam', zIndex: 1, startTime: 0 }, clipDurationForLayer);
                        addLayerIfNotExists({ type: 'audio', imagePath: mixdown1?.path, assetKey: 'mixdown1', zIndex: 0, startTime: 0 }, clipDurationForLayer);
                        addLayerIfNotExists({ type: 'audio', imagePath: mixdown2?.path, assetKey: 'mixdown2', zIndex: 0, startTime: 0 }, clipDurationForLayer);

                        return {
                            ...reel,
                            renderOptions: { ...reel.renderOptions, layers: newLayers }
                        };
                    });
                });

                if (Object.values(data.foundFiles).some(f => f !== null)) {
                    toast({ title: 'تمت إضافة الطبقات تلقائيًا', description: 'تمت إضافة ملفات الفيديو والصوت التي تم العثور عليها كطبقات.' });
                }

            } else {
                setMissingFiles(Object.keys(data.foundFiles || {}));
                toast({ title: 'لم يتم العثور على ملفات', description: data.message || 'لم يتم العثور على أي من الملفات القياسية. الرجاء الرفع يدويًا إذا لزم الأمر.', duration: 7000 });
            }
        } catch (error) {
            console.error("Error checking for existing video:", error);
            toast({ title: 'خطأ', description: 'حدث خطأ أثناء البحث عن ملف الفيديو.', variant: 'destructive' });
        } finally {
            setIsCheckingForVideo(false);
        }
    }, [toast]);
    
    useEffect(() => {
        if (selectedEpisode?.id && selectedPodcast?.id) {
            checkForExistingVideo(selectedPodcast.code, selectedEpisode.episodeCode);
        }
    }, [selectedEpisode?.id, selectedPodcast?.id, checkForExistingVideo]);


    const handleTimecodeNudge = useCallback((field: 'tcIn' | 'tcOut', amount: number) => {
        if (!selectedReel) return;
        const currentTime = selectedReel.renderOptions?.[field] || '00:00:00.000';
        const currentSeconds = timecodeUtils.parseTimecodeToSeconds(currentTime);
        const newSeconds = Math.max(0, currentSeconds + amount);
        const newTimecode = timecodeUtils.formatSecondsToHHMMSSms(newSeconds);
        onReelOptionsChange(selectedReel.id, { [field]: newTimecode });
    }, [selectedReel, onReelOptionsChange]);
    
    const onKeyframeDelete = useCallback((layerId: string | 'base-video', property: string, keyframeIndex: number) => {
        if (layerId === 'base-video') {
            if (!selectedReel) return;
            const newKeyframes = (selectedReel.renderOptions?.video?.position || []).filter((_, i) => i !== keyframeIndex);
            onReelOptionsChange(selectedReel.id, { video: { position: newKeyframes } });
        } else {
            onLayersChange(layers =>
                layers.map(l => {
                    if (l.id === selectedLayerId) {
                        const newLayer = { ...l };
                        const keyframeProp = `${property}Keyframes` as const;
                        const keyframeArray = (newLayer[keyframeProp as keyof LayerType] as Keyframe<any>[]) || [];
                        const updatedKeyframes = keyframeArray.filter((_, i) => i !== keyframeIndex);
                        (newLayer as any)[keyframeProp] = updatedKeyframes;
                        return newLayer;
                    }
                    return l;
                })
            );
        }
    }, [selectedReel, selectedLayerId, onLayersChange, onReelOptionsChange]);

    const handleDeleteAsset = useCallback(async (assetType: 'image' | 'font', assetKey: string, gcsPath: string) => {
        if (!selectedPodcast) return;
        
        try {
            const response = await fetch('/api/delete-file', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ gcsPath, podcastId: selectedPodcast.id, assetKey, assetType }),
            });
             const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'فشل حذف الأصل');
            
            toast({ title: "تم الحذف", description: `تم حذف الأصل '${assetKey}' بنجاح.` });
        } catch (error: any) {
            toast({ title: "خطأ في الحذف", description: error.message, variant: "destructive" });
        }
    }, [selectedPodcast, toast]);
    
    const handleApplyTemplate = useCallback((templateOptions: Partial<ReelRenderOptions>, target: 'all' | 'selected') => {
        setLocalReels(prevReels => {
            const reelsToUpdateIds = target === 'all'
                ? new Set(prevReels.map(r => r.id))
                : new Set(prevReels.filter(r => r.isSelected).map(r => r.id));

            return prevReels.map(reel => {
                if (reelsToUpdateIds.has(reel.id)) {
                    const newRenderOptions = {
                        ...(reel.renderOptions || {}),
                        ...templateOptions,
                        tcIn: reel.renderOptions?.tcIn, // Keep original timecodes
                        tcOut: reel.renderOptions?.tcOut,
                    };
                    return { ...reel, renderOptions: newRenderOptions };
                }
                return reel;
            });
        });
        toast({ title: "تم تطبيق القالب", description: `تم تطبيق الإعدادات على ${target === 'all' ? 'جميع' : 'المقاطع المحددة'}.`});
    }, [toast]);
    
    const handleTestVmConnection = async () => {
        setIsSavingVmIp(true); 
        toast({ title: 'جاري فحص الاتصال...', description: 'يتم إرسال طلب اختبار إلى جهاز الرندر.' });
        try {
            const response = await fetch('/api/vm-status', { method: 'POST' });
            const result = await response.json();
            if (!response.ok || !result.success) throw new Error(result.message || 'فشل فحص الاتصال.');
            toast({ title: '✅ الاتصال ناجح!', description: result.message || 'الجهاز متصل ويعمل.', className: 'bg-green-500 text-white' });
        } catch (error: any) {
            toast({ title: '❌ فشل الاتصال', description: error.message || 'تعذر الوصول إلى جهاز الرندر. تحقق من أنه يعمل وأن إعدادات الشبكة صحيحة.', variant: 'destructive', duration: 10000 });
        } finally {
            setIsSavingVmIp(false);
        }
    };
    
    const handleSaveVmIp = async () => {
        setIsSavingVmIp(true);
        const configDocRef = doc(db, currentAppPaths.appConfigurationDoc('render_server_config'));
        try {
            await setDoc(configDocRef, { vmIpAddress }, { merge: true });
            toast({ title: "تم حفظ الإعدادات", description: "تم تحديث عنوان IP لسيرفر الرندر بنجاح.", className: "bg-green-500 text-white" });
        } catch (e: any) {
            toast({ title: "خطأ في الحفظ", description: e.message || "فشل حفظ عنوان IP.", variant: "destructive" });
        } finally {
            setIsSavingVmIp(false);
        }
    };
    
    const handleReelSelectionToggle = (reelId: string) => {
        setLocalReels(prevReels =>
            prevReels.map(reel => reel.id === reelId ? { ...reel, isSelected: !reel.isSelected } : reel)
        );
    };

    const selectedCount = useMemo(() => localReels.filter(r => r.isSelected).length, [localReels]);
    
    const completedReels = useMemo(() => localReels.filter(r => r.renderStatus === 'completed' && r.finalUrl), [localReels]);
        
    const handleDownloadJson = useCallback(() => {
        if (!selectedPodcast) return;
        const selectedForRender = localReels.filter(r => r.isSelected);
        if (selectedForRender.length === 0) {
            toast({ title: 'لم يتم تحديد مقاطع', description: 'الرجاء تحديد مقطع واحد على الأقل لتنزيل بياناته.', variant: 'destructive' });
            return;
        }
        const apiPayload = {
            sourceVideoPath: highQualityVideoPath,
            podcastCode: selectedPodcast.code,
            episodeCode: selectedEpisode!.episodeCode,
            episodeId: selectedEpisodeId,
            reels: selectedForRender.map(reel => ({
                id: reel.id,
                number: reel.number,
                options: {
                    ...reel.renderOptions,
                    layers: (reel.renderOptions?.layers || []).map(layer => {
                        const { imageUrl, ...rest } = layer; // Exclude client-side only properties
                        return rest;
                    })
                }
            })),
        };
        const jsonString = JSON.stringify(cleanForFirestore(apiPayload), null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `render_payload_${selectedPodcast?.code}_${new Date().toISOString()}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }, [localReels, highQualityVideoPath, selectedPodcast, selectedEpisodeId, toast, selectedEpisode]);

    const handleDownloadAllAsZip = useCallback(async () => {
        const completed = localReels.filter(r => r.finalUrl);
        if (completed.length === 0) {
            toast({ title: 'لا توجد مقاطع مكتملة', variant: 'default' });
            return;
        }
    
        toast({ title: 'جاري تحضير ملف الـ ZIP...', description: 'قد تستغرق هذه العملية بعض الوقت.' });
    
        try {
            const filePaths = completed.map(reel => {
                const url = new URL(reel.finalUrl!);
                return url.pathname.substring(url.pathname.indexOf('/', 1) + 1);
            });
    
            const response = await fetch('/api/zip-reels', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filePaths })
            });
    
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'فشل إنشاء ملف الـ ZIP.');
            }
    
            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = `reels_export_${selectedEpisode?.episodeCode || 'export'}.zip`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(downloadUrl);
        } catch (error: any) {
            console.error("Error creating zip:", error);
            toast({ title: "خطأ في إنشاء الـ ZIP", description: error.message, variant: "destructive" });
        }
    }, [localReels, selectedEpisode?.episodeCode, toast]);


    const handleClearAllCompleted = useCallback(() => {
        setLocalReels(prev => prev.map(reel => 
            reel.finalUrl 
                ? { ...reel, finalUrl: undefined, progress: 0, renderStatus: 'pending' } 
                : reel
        ));
        toast({ title: 'تم الحذف محلياً', description: 'تمت إزالة روابط المقاطع المكتملة. اضغط "حفظ التغييرات" لتثبيت الحذف.' });
    }, [toast]);
    
    const handleJsonFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setJsonFile(file);
            const reader = new FileReader();
            reader.onload = (e) => {
                setJsonToRender(e.target?.result as string);
            };
            reader.readAsText(file);
        }
    };

    const handleRenderFromJson = async () => {
        if (!jsonToRender) {
            toast({ title: "لا يوجد محتوى", description: "الرجاء رفع ملف أو لصق محتوى JSON.", variant: "destructive" });
            return;
        }
        let payload;
        try {
            payload = JSON.parse(jsonToRender);
        } catch (e) {
            toast({ title: "خطأ في JSON", description: "محتوى الـ JSON غير صالح.", variant: "destructive" });
            return;
        }
        setIsRendering(true);
        try {
            const response = await fetch('/api/render-reels', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'فشل إرسال طلب الرندر.');
            toast({ title: "تم إرسال الطلب بنجاح", description: result.message, className: "bg-green-500 text-white" });
            setJsonFile(null);
            setJsonToRender('');
        } catch (error: any) {
            toast({ title: "خطأ في إرسال طلب الرندر", description: error.message, variant: "destructive" });
        } finally {
            setIsRendering(false);
        }
    };

    const handleTestWebhook = useCallback(async () => {
        if (!webhookUrl) {
            toast({ title: 'رابط Webhook مطلوب', description: 'الرجاء إدخال رابط Webhook.', variant: 'destructive' });
            return;
        }
        
        setIsTestingWebhook(true);
        
        try {
            const testPayload = {
                test: true,
                message: 'اختبار اتصال webhook',
                timestamp: new Date().toISOString(),
                source: 'reels-montage'
            };
            
            const response = await fetch(webhookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(testPayload)
            });
            
            if (response.ok) {
                toast({ 
                    title: '✅ نجح الاتصال!', 
                    description: `تم الاتصال بالسيرفر بنجاح. رمز الاستجابة: ${response.status}`,
                    className: 'bg-green-500 text-white'
                });
            } else {
                throw new Error(`فشل الاتصال. رمز الخطأ: ${response.status}`);
            }
            
        } catch (error: any) {
            toast({ 
                title: '❌ فشل الاتصال', 
                description: `لا يمكن الوصول إلى الـ webhook: ${error.message}`, 
                variant: 'destructive' 
            });
        } finally {
            setIsTestingWebhook(false);
        }
    }, [webhookUrl, toast]);

    const handleSendWebhook = useCallback(async () => {
        const selectedForWebhook = localReels.filter(r => r.isSelected);
        if (selectedForWebhook.length === 0) {
            toast({ title: 'لم يتم تحديد مقاطع', description: 'الرجاء تحديد مقطع واحد على الأقل لإرسال البيانات.', variant: 'destructive' });
            return;
        }
        
        if (!webhookUrl) {
            toast({ title: 'رابط Webhook مطلوب', description: 'الرجاء إدخال رابط Webhook.', variant: 'destructive' });
            return;
        }
        
        if (!selectedEpisode || !selectedPodcast) {
            toast({ title: 'معلومات ناقصة', description: 'الرجاء اختيار بودكاست وحلقة.', variant: 'destructive' });
            return;
        }
        
        setIsSendingWebhook(true);
        
        try {
            const guestProfile = allGuestProfiles.find(gp => gp.name === selectedEpisode.guestName);
            const response = await fetch('/api/send-webhook', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    webhookUrl,
                    episodeId: selectedEpisode.id,
                    podcastId: selectedPodcast.id,
                    selectedReels: selectedForWebhook,
                    guestName: selectedEpisode.guestName,
                    guestTitle: guestProfile?.fullTitle || '',
                    episodeCode: selectedEpisode.episodeCode
                }),
            });
            
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'فشل إرسال Webhook');
            
            toast({ 
                title: '✅ تم إرسال البيانات بنجاح', 
                description: `تم إرسال بيانات ${selectedForWebhook.length} مقطع مع ملفات التفريغ إلى السيرفر الخارجي`,
                className: 'bg-green-500 text-white',
                duration: 5000
            });
            setShowWebhookDialog(false);
            
        } catch (error: any) {
            console.error('Webhook sending error:', error);
            toast({ title: '❌ خطأ في إرسال Webhook', description: error.message, variant: 'destructive', duration: 8000 });
        } finally {
            setIsSendingWebhook(false);
        }
    }, [localReels, webhookUrl, selectedEpisode, selectedPodcast, toast, allGuestProfiles]);
    
    const createUnifiedPayload = useCallback(async (reelsToProcess: ReelForRender[]) => {
        if (!selectedEpisode || !selectedPodcast) return null;

        let transcriptData: TranscriptSegment[] = [];
        try {
            const transcriptRes = await fetch(`/api/get-cached-transcript?podcastCode=${selectedPodcast.code}&episodeCode=${selectedEpisode.episodeCode}`);
            if (transcriptRes.ok) {
                transcriptData = await transcriptRes.json();
            } else {
                console.warn("Could not fetch transcript for payload generation.");
            }
        } catch (e) {
            console.error("Error fetching transcript for payload", e);
        }

        const guestProfile = allGuestProfiles.find(gp => gp.name === selectedEpisode.guestName);
        
        return {
            podcastCode: selectedPodcast.code,
            episodeId: selectedEpisode.id,
            episodeCode: selectedEpisode.episodeCode,
            totalReelsCount: localReels.length,
            selectedReelsCount: reelsToProcess.length,
            reels: reelsToProcess.map(reel => {
                const startSeconds = timecodeUtils.parseTimecodeToSeconds(reel.tcIn);
                const endSeconds = timecodeUtils.parseTimecodeToSeconds(reel.tcOut);
                
                const reelTranscript = transcriptData.flatMap(segment => 
                  segment.words
                    .filter(word => word.startTime >= startSeconds && word.endTime <= endSeconds)
                    .map(word => ({
                      text: word.text,
                      start_time: word.startTime,
                      end_time: word.endTime,
                    }))
                );

                const reelNumberPadded = String(reel.number).padStart(2, '0');
                const reelName = `${reel.episodeCode}_SHORT_${reelNumberPadded}`;

                return {
                    id: reel.id,
                    number: parseInt(reel.number, 10),
                    episodeCode: reel.episodeCode,
                    name: reelName,
                    reelName: reelName, 
                    line1: reel.line1,
                    line2: reel.line2,
                    tcIn: reel.tcIn,
                    tcOut: reel.tcOut,
                    transcript: reelTranscript
                };
            }),
            guest: {
                name: selectedEpisode.guestName || '',
                fullTitle: guestProfile?.fullTitle || '',
                shortTitle: guestProfile?.shortTitle || '',
            },
        };
    }, [localReels, selectedEpisode, selectedPodcast, allGuestProfiles]);

    const handleBatchRenderV2 = useCallback(async () => {
        const reelsToRender = localReels.filter(r => r.isSelected);
        if (reelsToRender.length === 0) {
            toast({ title: 'لم يتم تحديد مقاطع', description: 'الرجاء تحديد مقطع واحد على الأقل للرندر.', variant: 'destructive' });
            return;
        }
        
        setIsRendering(true);
        try {
            const payload = await createUnifiedPayload(reelsToRender);
            if (!payload) {
                throw new Error("فشل في إعداد بيانات الرندر.");
            }

            const response = await fetch('/api/render-reels-v2', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'فشل إرسال طلب الرندر 2.');
            }

            toast({ title: "تم إرسال الطلب بنجاح (Render 2)", description: result.message, className: "bg-blue-500 text-white" });

        } catch (error: any) {
            console.error("Error with Render 2:", error);
            toast({ title: "خطأ في إرسال طلب رندر 2", description: error.message, variant: "destructive" });
        } finally {
            setIsRendering(false);
        }
    }, [localReels, createUnifiedPayload, toast]);

    const handleDownloadPayloadJson = useCallback(async () => {
        const reelsToDownload = localReels.filter(r => r.isSelected);
        if (reelsToDownload.length === 0) {
            toast({ title: 'لم يتم تحديد مقاطع', description: 'الرجاء تحديد مقطع واحد على الأقل.', variant: 'destructive' });
            return;
        }
        try {
            const payload = await createUnifiedPayload(reelsToDownload);
            if (!payload) throw new Error("فشل في إعداد بيانات JSON.");

            const jsonString = JSON.stringify(payload, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `render_v2_payload_${selectedEpisode?.episodeCode}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        } catch (error: any) {
            toast({ title: "خطأ في تحضير JSON", description: error.message, variant: "destructive" });
        }
    }, [localReels, createUnifiedPayload, toast, selectedEpisode]);


    const onAddLayer = useCallback((layerData: Omit<LayerType, 'id'>) => {
        if (!selectedReel) return;
        
        let newDuration = 12; // Default for text/image

        const newLayer: LayerType = { 
            id: layerData.assetKey ? `${layerData.assetKey}-${uuidv4()}`: uuidv4(),
            ...layerData, 
            startTime: 0, 
            duration: newDuration,
            visible: true, 
            position: { x: 0.5, y: 0.5 },
            scale: 1,
            rotation: 0,
            opacity: 1,
            scaleX: 1,
            positionKeyframes: [],
            scaleKeyframes: [],
            rotationKeyframes: [],
            opacityKeyframes: [],
        };
        onLayersChange((prevLayers) => [...(prevLayers || []), newLayer]);
    }, [selectedReel, onLayersChange]);

    if (isAuthLoading || isPermissionsLoading || isLoadingData) {
        return <div className="flex items-center justify-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
    }
    if (canAccess === false) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center" dir="rtl">
                <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
                <h1 className="text-2xl font-bold mb-2">وصول غير مصرح به</h1>
                <p className="text-muted-foreground mb-6">ليس لديك الصلاحية لعرض هذه الصفحة.</p>
                <Button onClick={() => router.push('/')}><Home className="ml-2 h-4 w-4" /> العودة للرئيسية</Button>
            </div>
        );
    }
    
    return (
        <TooltipProvider>
        <div className="min-h-screen bg-muted/40 text-foreground flex flex-col p-4 md:p-6" dir="rtl">
            <header className="mb-6 flex justify-between items-center">
                <div> <h1 className="text-2xl md:text-3xl font-bold font-headline">مونتاج المقاطع القصيرة</h1> <p className="text-sm text-muted-foreground">تصميم ومونتاج وتصدير المقاطع القصيرة بمرونة.</p> </div>
                <div className="flex items-center gap-2">
                    <Button onClick={() => router.push('/')} variant="outline" size="sm"> <Home className="w-4 h-4 ml-2" /> الصفحة الرئيسية </Button>
                </div>
            </header>
            
            <div className="grid grid-cols-12 gap-4 flex-grow">
                <div className="col-span-12 lg:col-span-3 flex flex-col gap-4">
                    <Card>
                        <CardHeader className="p-3">
                            <CardTitle className="text-base">1. اختيار المشروع</CardTitle>
                        </CardHeader>
                        <CardContent className="p-3 pt-0 grid grid-cols-2 gap-2">
                            <Select value={selectedPodcastId} onValueChange={id => { setSelectedPodcastId(id); setSelectedEpisodeId(null); setSelectedReelId(null); }}>
                                <SelectTrigger><SelectValue placeholder="اختر بودكاست..." /></SelectTrigger>
                                <SelectContent>
                                    {allPodcasts.map(p => <SelectItem key={p.id} value={p.id}>{p.name.replace(/^\d+_/,'')}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <Select value={selectedEpisodeId || ''} onValueChange={id => setSelectedEpisodeId(id)} disabled={!selectedPodcastId}>
                                <SelectTrigger><SelectValue placeholder="اختر حلقة..." /></SelectTrigger>
                                <SelectContent>
                                    {availableEpisodes.map(ep => <SelectItem key={ep.id} value={ep.id}>{ep.episodeCode} - {ep.guestName}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="p-3">
                            <CardTitle className="text-base">2. فيديو المصدر</CardTitle>
                        </CardHeader>
                        <CardContent className="p-3 pt-0 space-y-2">
                            <div className="flex items-center gap-2">
                                <Input
                                    readOnly
                                    value={highQualityVideoPath.split('/').pop() || ''}
                                    placeholder="لا يوجد مصدر فيديو"
                                    className="bg-input h-9 text-xs"
                                />
                                <Button variant="outline" size="icon" className="h-9 w-9 shrink-0" onClick={() => selectedPodcast && selectedEpisode && checkForExistingVideo(selectedPodcast.code, selectedEpisode.episodeCode)} disabled={!selectedEpisodeId || isCheckingForVideo}>
                                    {isCheckingForVideo ? <Loader2 className="w-4 h-4 animate-spin"/> : <RefreshCcw className="w-4 h-4" />}
                                </Button>
                            </div>
                            {missingFiles.length > 0 && (
                                <div className="p-2 border border-dashed border-destructive/50 bg-destructive/10 rounded-md text-xs">
                                    <p className="font-semibold text-destructive">ملفات ناقصة:</p>
                                    <ul className="list-disc list-inside">
                                        {missingFiles.map(f => <li key={f}>{f}</li>)}
                                    </ul>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                    
                    <Card className="flex-1 flex flex-col">
                        <CardHeader className="p-3 flex flex-row items-center justify-between">
                            <CardTitle className="text-base">قائمة المقاطع ({localReels.length})</CardTitle>
                            <div className="flex items-center">
                                <Label htmlFor="select-all-reels" className="text-xs mr-2">تحديد الكل</Label>
                                <Checkbox
                                    id="select-all-reels"
                                    checked={localReels.length > 0 && selectedCount === localReels.length}
                                    onCheckedChange={(checked) => {
                                        const newSelectionState = !!checked;
                                        setLocalReels(prev => prev.map(r => ({ ...r, isSelected: newSelectionState })));
                                    }}
                                />
                            </div>
                        </CardHeader>
                        <CardContent className="p-2 flex-1 flex flex-col">
                            <ScrollArea className="flex-grow h-64">
                                <div className="space-y-1 pr-2">
                                    {localReels.map((reel) => (
                                        <ReelListItem
                                            key={reel.id}
                                            reel={reel}
                                            isSelected={selectedReelId === reel.id}
                                            onSelect={() => setSelectedReelId(reel.id)}
                                            onCheckboxChange={() => handleReelSelectionToggle(reel.id)}
                                            episodeCode={selectedEpisode?.episodeCode}
                                        />
                                    ))}
                                    {localReels.length === 0 && <p className="col-span-4 text-xs text-center text-muted-foreground py-10">اختر حلقة لعرض المقاطع.</p>}
                                </div>
                            </ScrollArea>
                        </CardContent>
                    </Card>
                </div>
                
                <div className="col-span-12 lg:col-span-5 flex flex-col gap-4">
                    <VisualReelEditor
                        ref={playerRef}
                        selectedReel={selectedReel}
                        selectedEpisode={selectedEpisode}
                        sourceVideoUrl={sourceVideoUrl}
                        isMuted={isMuted}
                        assets={montageAssets}
                        fonts={montageFonts}
                        allGuestProfiles={allGuestProfiles}
                        onLayersChange={onLayersChange}
                        onLayerSelect={setSelectedLayerId}
                        selectedLayerId={selectedLayerId}
                        onTimeUpdate={setRelativeCurrentTime}
                        onStateChange={handlePlayerStateChange}
                    />

                    <VideoPlayer
                        selectedReel={selectedReel}
                        isPlaying={isPlaying}
                        isMuted={isMuted}
                        onPlayPause={handlePlayPause}
                        onReplay={handleReplay}
                        onSeek={handleSeek}
                        onToggleMute={toggleMute}
                        relativeCurrentTime={relativeCurrentTime}
                        clipDuration={clipDuration}
                        onAddKeyframe={() => {}}
                        onTimecodeNudge={handleTimecodeNudge}
                        onGoToStart={() => { if(playerRef.current) playerRef.current.seekTo(0) }}
                        onGoToEnd={() => { if(playerRef.current && clipDuration > 0) playerRef.current.seekTo(clipDuration) }}
                    />
                    <Timeline
                        layers={selectedReel?.renderOptions?.layers || []}
                        selectedLayerId={selectedLayerId}
                        onLayerSelect={setSelectedLayerId}
                        onLayersChange={onLayersChange}
                        currentTime={relativeCurrentTime}
                        onSeek={(time) => { if (playerRef.current) playerRef.current.seekTo(time); }}
                        clipDuration={clipDuration}
                        selectedReel={selectedReel}
                        onKeyframeDelete={onKeyframeDelete}
                    />
                </div>

                <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
                    <LayerInspector
                        selectedLayer={selectedLayer}
                        selectedReel={selectedReel}
                        selectedPodcast={selectedPodcast}
                        selectedEpisode={selectedEpisode} 
                        allGuestProfiles={allGuestProfiles}
                        clipDuration={clipDuration}
                        relativeCurrentTime={relativeCurrentTime}
                        onLayersChange={onLayersChange}
                        onLayerSelect={setSelectedLayerId}
                        selectedLayerId={selectedLayerId}
                        onDeleteAsset={handleDeleteAsset}
                        onReelOptionsChange={onReelOptionsChange}
                        onPodcastUpdate={onPodcastUpdate}
                        onAssetUpload={onAssetUpload}
                        onFontUpload={onFontUpload}
                        isUploadingAsset={isUploadingAsset}
                        isUploadingFont={isUploadingFont}
                        onAddLayer={onAddLayer}
                        isSavingReelData={false}
                        onApplyTemplate={handleApplyTemplate}
                        onBatchRender={handleBatchRender}
                        selectedCount={selectedCount}
                        isRendering={isRendering}
                        handleDownloadJson={handleDownloadJson}
                        handleJsonFileChange={handleJsonFileChange}
                        jsonFile={jsonFile}
                        jsonToRender={jsonToRender}
                        setJsonToRender={setJsonToRender}
                        handleRenderFromJson={handleRenderFromJson}
                        onKeyframeDelete={onKeyframeDelete}
                        handleBatchRenderV2={handleBatchRenderV2}
                        handleDownloadPayloadJson={handleDownloadPayloadJson}
                    />
                </div>
            </div>
            <Accordion type="single" collapsible className="w-full mt-4 sticky bottom-0 z-40 bg-background/90 backdrop-blur-sm border-t">
                <AccordionItem value="render-status" className="border-b-0">
                    <AccordionTrigger className="p-3 hover:no-underline [&[data-state=open]>svg]:text-primary">
                        <div className="flex justify-between items-center w-full">
                            <h2 className="text-xl font-bold font-headline">حالة التصدير والمقاطع المكتملة</h2>
                        </div>
                    </AccordionTrigger>
                    <AccordionContent className="p-3 pt-0">
                        <div className="flex justify-end items-center mb-2 gap-2 pb-4">
                            <AlertDialog>
                                <AlertDialogTrigger asChild>
                                    <Button variant="outline" size="sm" disabled={completedReels.length === 0}><Download className="w-4 h-4 ml-2"/>تنزيل الكل كملف ZIP</Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                        <AlertDialogTitle>تأكيد تنزيل جميع المقاطع؟</AlertDialogTitle>
                                        <AlertDialogDescription>
                                            سيؤدي هذا إلى بدء عملية ضغط وتنزيل لـ {completedReels.length} مقطع. قد تستغرق هذه العملية بعض الوقت.
                                        </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                        <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                        <AlertDialogAction onClick={handleDownloadAllAsZip} className="bg-primary hover:bg-primary/90">نعم، ضغط وتنزيل</AlertDialogAction>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                            <AlertDialog>
                                <AlertDialogTrigger asChild>
                                    <Button variant="destructive" size="sm" disabled={completedReels.length === 0}><Trash2 className="w-4 h-4 ml-2"/>حذف الكل</Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                        <AlertDialogTitle>تأكيد حذف جميع المقاطع المكتملة؟</AlertDialogTitle>
                                        <AlertDialogDescription>
                                            سيؤدي هذا إلى إزالة روابط الفيديوهات المكتملة وإعادة حالتها إلى "معلقة". ستحتاج إلى إعادة مونتاجها مرة أخرى.
                                        </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                        <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                        <AlertDialogAction onClick={handleClearAllCompleted} className="bg-destructive hover:bg-destructive/90">نعم، حذف الكل</AlertDialogAction>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                        </div>
                        <ScrollArea className="pb-4">
                            <div className="flex space-x-4 rtl:space-x-reverse pb-4">
                                {localReels
                                .filter(reel => reel.renderStatus === 'rendering' || reel.renderStatus === 'completed' || reel.renderStatus === 'failed')
                                .sort((a,b) => (a.renderStatus === 'rendering' ? -1 : 1) - (b.renderStatus === 'rendering' ? -1 : 1) || parseInt(a.number) - parseInt(b.number))
                                .map(reel => (
                                    <CompletedReelCard key={reel.id} reel={reel} setVideoInModal={setVideoInModal} toast={toast} />
                                ))}
                            </div>
                            <ScrollBar orientation="horizontal" />
                        </ScrollArea>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
            <Dialog open={!!videoInModal} onOpenChange={(isOpen) => !isOpen && setVideoInModal(null)}>
                <DialogContent className="max-w-4xl h-[80vh] flex flex-col p-2 bg-black/90 border-muted">
                    <DialogHeader className="p-2"><DialogTitle className="text-white">معاينة الفيديو</DialogTitle></DialogHeader>
                    {videoInModal && (<iframe src={getGoogleDriveEmbedUrl(videoInModal) || videoInModal} key={videoInModal} width="100%" height="100%" allow="autoplay" className="rounded-md border-0 flex-grow" title="معاينة فيديو الشورت"></iframe>)}
                    <DialogFooter className="p-2"><DialogClose asChild><Button variant="outline" onClick={() => setVideoInModal(null)}>إغلاق</Button></DialogClose></DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
        </TooltipProvider>
    );
}